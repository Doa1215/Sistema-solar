# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 12:32:43 2024

@author: akon_
"""

# main.py
import sys
import os
import numpy as np
from OpenGL.GL import *
from PIL import Image 
#Sino se puede renderiza solo documentar las lineas marcadas con ------ para que se pueda visualizar
# Crear un directorio para guardar los fotogramas en la carpeta Planetas 
output_dir = os.path.join('Planetas', 'frames') #----
if not os.path.exists(output_dir): #-------
    os.makedirs(output_dir)#--------

# Agregar el directorio 'core' a la ruta del sistema
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))

# Importar las clases necesarias
from core.base import Base
from core.renderer import Renderer
from core.scene import Scene
from core.camera import Camera
from core.mesh import Mesh
from geometry.sphereGeometry import SphereGeometry
from geometry.ringGeometry import RingGeometry
from material.textureMaterial import TextureMaterial
from core.texture import Texture

class SolarSystem(Base):
    def initialize(self):
        print("Inicializando programa...")
        self.renderer = Renderer()
        self.scene = Scene()
        self.camera = Camera(aspectRatio=800/600)
        self.camera.setPosition([0, 0, 100])  # Ajuste de la posición inicial de la cámara

        # Cargar las texturas usando rutas relativas
        sunTexture = Texture.fromFile(os.path.join("Planetas", "2k_sun.jpg"))
        mercuryTexture = Texture.fromFile(os.path.join("Planetas", "2k_venus_surface.jpg"))
        venusTexture = Texture.fromFile(os.path.join("Planetas", "2k_earth_daymap.jpg"))
        earthTexture = Texture.fromFile(os.path.join("Planetas", "2k_mars.jpg"))
        marsTexture = Texture.fromFile(os.path.join("Planetas", "2k_jupiter.jpg"))
        jupiterTexture = Texture.fromFile(os.path.join("Planetas", "2k_saturn.jpg"))
        saturnTexture = Texture.fromFile(os.path.join("Planetas", "2k_uranus.jpg"))
        uranusTexture = Texture.fromFile(os.path.join("Planetas", "2k_neptune.jpg"))
        neptuneTexture = Texture.fromFile(os.path.join("Planetas", "2k_sun.jpg"))
        moonTexture = Texture.fromFile(os.path.join("Planetas", "2k_moon.jpg"))
        #saturnRingTexture = Texture.fromFile(os.path.join("Planetas", "2k_saturn_ring_alpha.png"))  # PNG para el anillo de Saturno

        # Crear los materiales con texturas
        sunMaterial = TextureMaterial(sunTexture)
        mercuryMaterial = TextureMaterial(mercuryTexture)
        venusMaterial = TextureMaterial(venusTexture)
        earthMaterial = TextureMaterial(earthTexture)
        marsMaterial = TextureMaterial(marsTexture)
        jupiterMaterial = TextureMaterial(jupiterTexture)
        saturnMaterial = TextureMaterial(saturnTexture)
        uranusMaterial = TextureMaterial(uranusTexture)
        neptuneMaterial = TextureMaterial(neptuneTexture)
        moonMaterial = TextureMaterial(moonTexture)
        #saturnRingMaterial = TextureMaterial(saturnRingTexture)

        # Crear las geometrías de los planetas, la luna y el anillo de Saturno
        sunGeometry = SphereGeometry(radius=10)  # Aumentar el tamaño del sol
        mercuryGeometry = SphereGeometry(radius=0.38)
        venusGeometry = SphereGeometry(radius=0.95)
        earthGeometry = SphereGeometry(radius=1)
        marsGeometry = SphereGeometry(radius=0.53)  # Ajustar el tamaño de Marte
        jupiterGeometry = SphereGeometry(radius=11)
        saturnGeometry = SphereGeometry(radius=9)
        uranusGeometry = SphereGeometry(radius=4)
        neptuneGeometry = SphereGeometry(radius=3.88)
        moonGeometry = SphereGeometry(radius=0.27)
        #saturnRingGeometry = RingGeometry(innerRadius=10, outerRadius=15)  # Geometría del anillo de Saturno

        # Crear los objetos de malla para los planetas, el sol, la luna y el anillo de Saturno
        self.sun = Mesh(sunGeometry, sunMaterial)
        self.mercury = Mesh(mercuryGeometry, mercuryMaterial)
        self.venus = Mesh(venusGeometry, venusMaterial)
        self.earth = Mesh(earthGeometry, earthMaterial)
        self.mars = Mesh(marsGeometry, marsMaterial)
        self.jupiter = Mesh(jupiterGeometry, jupiterMaterial)
        self.saturn = Mesh(saturnGeometry, saturnMaterial)
        self.uranus = Mesh(uranusGeometry, uranusMaterial)
        self.neptune = Mesh(neptuneGeometry, neptuneMaterial)
        self.moon = Mesh(moonGeometry, moonMaterial)
        #self.saturnRing = Mesh(saturnRingGeometry, saturnRingMaterial)

        # Añadir los planetas a sus respectivos padres
        self.earth.add(self.moon)
        #self.saturn.add(self.saturnRing)

        # Posicionar los planetas con distancias incrementadas
        self.sun.setPosition([0, 0, 0])
        self.mercury.setPosition([15, 0, 0])
        self.venus.setPosition([25, 0, 0])
        self.earth.setPosition([35, 0, 0])
        self.mars.setPosition([45, 0, 0])
        self.jupiter.setPosition([75, 0, 0])
        self.saturn.setPosition([105, 0, 0])
        self.uranus.setPosition([125, 0, 0])
        self.neptune.setPosition([145, 0, 0])
        self.moon.setPosition([1.5, 0, 0])  # Posicionar la luna en relación con la Tierra
        #self.saturnRing.setPosition([0, 0, 0])  # El anillo de Saturno se mantiene en la misma posición que Saturno

        # Añadir el sol y los planetas a la escena
        self.scene.add(self.sun)
        self.scene.add(self.mercury)
        self.scene.add(self.venus)
        self.scene.add(self.earth)
        self.scene.add(self.mars)
        self.scene.add(self.jupiter)
        self.scene.add(self.saturn)
        self.scene.add(self.uranus)
        self.scene.add(self.neptune)

        print("Escena inicializada correctamente")

    def update(self):
        # Aquí puedes implementar movimientos de la cámara
        self.input.update()
        if self.input.isKeyPressed("w"):
            self.camera.translate(0, 0, -0.5)
        if self.input.isKeyPressed("s"):
            self.camera.translate(0, 0, 0.5)
        if self.input.isKeyPressed("a"):
            self.camera.translate(-0.5, 0, 0)
        if self.input.isKeyPressed("d"):
            self.camera.translate(0.5, 0, 0)
        if self.input.isKeyPressed("q"):
            self.camera.rotateX(0.05)
        if self.input.isKeyPressed("e"):
            self.camera.rotateX(-0.05)
        if self.input.isKeyPressed("up"):
            self.camera.rotateY(0.05)
        if self.input.isKeyPressed("down"):
            self.camera.rotateY(-0.05)
        if self.input.isKeyPressed("left"):
            self.camera.rotateZ(0.05)
        if self.input.isKeyPressed("right"):
            self.camera.rotateZ(-0.05)

        # Mantener la luna orbitando alrededor de la Tierra
        earthPosition = self.earth.getPosition()
        moonOrbitRadius = 1.5  # Radio de la órbita de la luna
        moonAngle = self.time * 0.5  # Velocidad de rotación de la luna alrededor de la Tierra

        moonX = earthPosition[0] + moonOrbitRadius * np.cos(moonAngle)
        moonY = earthPosition[1] + moonOrbitRadius * np.sin(moonAngle)
        self.moon.setPosition([moonX, moonY, earthPosition[2]])

        # Traslación de los planetas alrededor del Sol
        time = self.time  # Tiempo transcurrido
        self.mercury.setPosition([15 * np.cos(time * 4.15), 0, 15 * np.sin(time * 4.15)])
        self.venus.setPosition([25 * np.cos(time * 1.62), 0, 25 * np.sin(time * 1.62)])
        self.earth.setPosition([35 * np.cos(time * 1), 0, 35 * np.sin(time * 0.5)])
        self.mars.setPosition([45 * np.cos(time * 0.53), 0, 45 * np.sin(time * 0.53)])
        self.jupiter.setPosition([75 * np.cos(time * 0.084), 0, 75 * np.sin(time * 0.084)])
        self.saturn.setPosition([105 * np.cos(time * 0.033), 0, 105 * np.sin(time * 0.033)])
        self.uranus.setPosition([125 * np.cos(time * 0.011), 0, 125 * np.sin(time * 0.011)])
        self.neptune.setPosition([145 * np.cos(time * 0.006), 0, 145 * np.sin(time * 0.006)])

        # Rotar los planetas sobre su eje
        self.mercury.rotateY(0.010)
        self.venus.rotateY(0.008)
        self.earth.rotateY(0.007)
        self.mars.rotateY(0.006)
        self.jupiter.rotateY(0.005)
        self.saturn.rotateY(0.004)
        self.uranus.rotateY(0.003)
        self.neptune.rotateY(0.002)
        
        # Renderizar la escena 
        self.renderer.render(self.scene, self.camera)
        
        # Guardar el fotograma como una imagen 
        frame_number = int(self.time * 30) #------
        # Supongamos 30 fps 
        glPixelStorei(GL_PACK_ALIGNMENT, 1) #-----
        data = glReadPixels(0, 0, 800, 600, GL_RGBA, GL_UNSIGNED_BYTE) #----
        image = Image.frombytes("RGBA", (800, 600), data) #-----
        image = image.transpose(Image.FLIP_TOP_BOTTOM) #-----
        image.save(os.path.join(output_dir, f'frame_{frame_number:04d}.png'))#---- 
        print(f"Fotograma {frame_number} guardado.")#---------

# Instanciar esta clase y ejecutar el programa
SolarSystem(screenSize=[800, 600]).run()



