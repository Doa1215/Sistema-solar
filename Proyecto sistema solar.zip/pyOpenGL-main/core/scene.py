from core.object3D import Object3D

class Scene(Object3D):
    def __init__(self):
        super().__init__() 