# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 08:25:25 2024

@author: akon_
"""

# geometry/ringGeometry.py
from OpenGL.GL import *
import numpy as np

class RingGeometry:
    def __init__(self, innerRadius=10, outerRadius=15, segments=64):
        self.vertexCount = segments * 2

        # Create vertices for the ring
        vertices = []
        for i in range(segments):
            angle = 2 * np.pi * i / segments
            xInner = innerRadius * np.cos(angle)
            yInner = innerRadius * np.sin(angle)
            xOuter = outerRadius * np.cos(angle)
            yOuter = outerRadius * np.sin(angle)

            vertices.append([xInner, yInner, 0])
            vertices.append([xOuter, yOuter, 0])

        self.vertices = np.array(vertices, dtype=np.float32)

    def getVertexData(self):
        return self.vertices
